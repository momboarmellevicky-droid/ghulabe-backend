# Ghulabe Cybersecurity Platform

## Architecture Cloud Native Mobile-First

Ghulabe est conçu pour être développé, maintenu et déployé depuis un smartphone.

Architecture:
Frontend React -> Services Cloud -> Supabase -> Services IA/Paiement

Technologies:
- React + TypeScript
- Node/TypeScript (migration progressive vers fonctions cloud)
- Supabase
- Gemini AI
- Stripe

Statut:
Phase 1 documentation et Phase 2 restructuration modules.
