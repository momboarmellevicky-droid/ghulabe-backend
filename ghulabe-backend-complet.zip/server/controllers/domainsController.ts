import { Request, Response } from 'express';
import { listDomainsForUser } from '../services/domainsService';

export async function getMyDomains(req: Request, res: Response): Promise<void> {
  if (!req.user?.id) {
    res.status(401).json({ error_fr: 'Non authentifié.' });
    return;
  }
  try {
    const domains = await listDomainsForUser(req.user.id);
    res.status(200).json({ domains });
  } catch (err: any) {
    res.status(500).json({ error_fr: 'Erreur lors de la récupération des domaines.', details: err.message });
  }
}
