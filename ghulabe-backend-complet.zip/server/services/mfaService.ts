import crypto from 'crypto';
import { authenticator } from 'otplib';
import { supabaseAdmin } from '../config/supabase';
import { encryptAES256, decryptAES256, generateAuditLog } from '../utils/crypto';

const BACKUP_CODES_COUNT = 8;
const ISSUER = 'GHULABE';

function hashBackupCode(code: string): string {
  return crypto.createHash('sha256').update(code).digest('hex');
}

function generateBackupCodes(): string[] {
  return Array.from({ length: BACKUP_CODES_COUNT }, () =>
    crypto.randomBytes(5).toString('hex').toUpperCase() // ex: A1B2C3D4E5
  );
}

/**
 * Étape 1 de l'enrôlement : génère un secret TOTP + des codes de secours,
 * stocke le secret chiffré (AES-256) et les codes hashés (SHA-256) — jamais
 * en clair en base. is_enabled reste false tant que enrollConfirm() n'a pas
 * validé un premier code, pour éviter un enrôlement fantôme non testé.
 * Retourne l'URL otpauth:// (à encoder en QR code côté front) et les codes
 * de secours EN CLAIR une seule fois (à afficher/télécharger immédiatement).
 */
export async function startMfaEnrollment(userId: string, email: string, ip: string) {
  const secret = authenticator.generateSecret();
  const backupCodesPlain = generateBackupCodes();
  const backupCodesHashed = backupCodesPlain.map(hashBackupCode);

  const { error } = await supabaseAdmin
    .from('user_mfa')
    .upsert(
      {
        user_id: userId,
        totp_secret_encrypted: encryptAES256(secret),
        backup_codes_hashed: backupCodesHashed,
        is_enabled: false,
        enrolled_at: null,
      },
      { onConflict: 'user_id' }
    );

  if (error) throw new Error(error.message);

  generateAuditLog({
    action: 'MFA_ENROLLMENT_STARTED',
    userId,
    ipAddress: ip,
    status: 'SUCCESS',
    details: 'Secret TOTP généré, en attente de confirmation.',
  });

  const otpauthUrl = authenticator.keyuri(email, ISSUER, secret);
  return { otpauthUrl, backupCodes: backupCodesPlain };
}

/**
 * Étape 2 : confirme l'enrôlement avec le premier code TOTP saisi par
 * l'utilisateur. Active is_enabled=true uniquement si le code est valide —
 * garantit que l'utilisateur a bien configuré son app d'authentification
 * avant que le MFA ne devienne obligatoire pour son compte.
 */
export async function confirmMfaEnrollment(userId: string, token: string, ip: string): Promise<boolean> {
  const { data, error } = await supabaseAdmin
    .from('user_mfa')
    .select('totp_secret_encrypted')
    .eq('user_id', userId)
    .single();

  if (error || !data) return false;

  const secret = decryptAES256(data.totp_secret_encrypted);
  const isValid = authenticator.check(token, secret);

  if (!isValid) {
    generateAuditLog({
      action: 'MFA_ENROLLMENT_CONFIRM_FAILED',
      userId, ipAddress: ip, status: 'BLOCKED',
      details: 'Code TOTP invalide lors de la confirmation d\'enrôlement.',
    });
    return false;
  }

  await supabaseAdmin
    .from('user_mfa')
    .update({ is_enabled: true, enrolled_at: new Date().toISOString(), last_used_at: new Date().toISOString() })
    .eq('user_id', userId);

  generateAuditLog({
    action: 'MFA_ENROLLMENT_CONFIRMED',
    userId, ipAddress: ip, status: 'SUCCESS',
    details: 'MFA activé avec succès pour ce compte.',
  });

  return true;
}

/**
 * Vérifie un code lors d'une connexion : accepte un TOTP valide OU un
 * backup code (à usage unique — il est retiré de la liste une fois utilisé).
 */
export async function verifyMfaCode(userId: string, code: string, ip: string): Promise<boolean> {
  const { data, error } = await supabaseAdmin
    .from('user_mfa')
    .select('totp_secret_encrypted, backup_codes_hashed, is_enabled')
    .eq('user_id', userId)
    .single();

  if (error || !data || !data.is_enabled) return false;

  const secret = decryptAES256(data.totp_secret_encrypted);
  if (authenticator.check(code, secret)) {
    await supabaseAdmin.from('user_mfa').update({ last_used_at: new Date().toISOString() }).eq('user_id', userId);
    generateAuditLog({ action: 'MFA_TOTP_VERIFIED', userId, ipAddress: ip, status: 'SUCCESS', details: 'Code TOTP valide.' });
    return true;
  }

  const hashed = hashBackupCode(code.toUpperCase().replace(/\s/g, ''));
  const codes: string[] = data.backup_codes_hashed || [];
  if (codes.includes(hashed)) {
    const remaining = codes.filter((c: string) => c !== hashed);
    await supabaseAdmin
      .from('user_mfa')
      .update({ backup_codes_hashed: remaining, last_used_at: new Date().toISOString() })
      .eq('user_id', userId);

    generateAuditLog({
      action: 'MFA_BACKUP_CODE_USED',
      userId, ipAddress: ip, status: 'SUCCESS',
      details: `Code de secours utilisé (${remaining.length} restants).`,
    });
    return true;
  }

  generateAuditLog({
    action: 'MFA_VERIFY_FAILED',
    userId, ipAddress: ip, status: 'BLOCKED',
    details: 'Code TOTP et backup code tous deux invalides.',
  });
  return false;
}

export async function isMfaEnabled(userId: string): Promise<boolean> {
  const { data } = await supabaseAdmin.from('user_mfa').select('is_enabled').eq('user_id', userId).single();
  return Boolean(data?.is_enabled);
}
