import { Router } from 'express';
import { getMyAlerts, markAlertRead } from '../controllers/alertsController';
import { requireAuth } from '../middleware/authMiddleware';

const router = Router();

router.get('/', requireAuth, getMyAlerts);
router.patch('/:alertId/read', requireAuth, markAlertRead);

export default router;
