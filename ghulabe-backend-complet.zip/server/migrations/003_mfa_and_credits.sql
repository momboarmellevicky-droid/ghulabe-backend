-- ============================================================
-- PATCH 003 — user_mfa + scan_credits (tables neuves, additif)
-- ============================================================

CREATE TABLE IF NOT EXISTS user_mfa (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  totp_secret_encrypted TEXT NOT NULL,       -- secret TOTP chiffré (AES-256, crypto.ts existant)
  backup_codes_hashed TEXT[] NOT NULL,       -- SHA-256 de chaque code, jamais le code en clair
  is_enabled BOOLEAN NOT NULL DEFAULT false, -- true seulement après confirmation du 1er code
  enrolled_at TIMESTAMPTZ,
  last_used_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE user_mfa ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "user_mfa_select_own" ON user_mfa;
CREATE POLICY "user_mfa_select_own" ON user_mfa
  FOR SELECT USING (user_id = auth.uid());
-- Pas de policy INSERT/UPDATE/DELETE pour le front : uniquement le backend
-- (service_role) écrit dans cette table — un secret TOTP ne doit jamais
-- transiter ni être modifiable directement depuis le client.

DROP TRIGGER IF EXISTS trg_user_mfa_updated_at ON user_mfa;
CREATE TRIGGER trg_user_mfa_updated_at BEFORE UPDATE ON user_mfa
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();


CREATE TABLE IF NOT EXISTS scan_credits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  plan TEXT NOT NULL DEFAULT 'gratuit' CHECK (plan IN ('gratuit','gardien','pentest_premium')),
  credits_remaining INT NOT NULL DEFAULT 10,
  credits_reset_at TIMESTAMPTZ NOT NULL DEFAULT (now() + interval '1 hour'),
  total_scans_used INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE scan_credits ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "scan_credits_select_own" ON scan_credits;
CREATE POLICY "scan_credits_select_own" ON scan_credits
  FOR SELECT USING (user_id = auth.uid());
-- Écriture réservée au backend (service_role) : décrémenter ses propres
-- crédits depuis le front serait triche pure.

DROP TRIGGER IF EXISTS trg_scan_credits_updated_at ON scan_credits;
CREATE TRIGGER trg_scan_credits_updated_at BEFORE UPDATE ON scan_credits
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
