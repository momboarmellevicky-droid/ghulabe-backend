# Déploiement mobile

Workflow:
Téléphone -> GitHub -> Build Cloud -> Production

Aucun serveur personnel permanent n'est requis.
Les secrets restent dans les environnements cloud.
