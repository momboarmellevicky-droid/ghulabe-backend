import { Request, Response } from 'express';
import { startMfaEnrollment, confirmMfaEnrollment, verifyMfaCode } from '../services/mfaService';

export async function enrollMfa(req: Request, res: Response): Promise<void> {
  if (!req.user?.id || !req.user.email) {
    res.status(401).json({ error_fr: 'Non authentifié.' });
    return;
  }
  const ip = req.ip || req.socket.remoteAddress || 'unknown-ip';
  try {
    const { otpauthUrl, backupCodes } = await startMfaEnrollment(req.user.id, req.user.email, ip);
    res.status(200).json({
      message_fr: "Scannez le QR code (généré depuis otpauthUrl) avec votre application d'authentification, puis confirmez avec un code via /confirm.",
      otpauthUrl,
      backupCodes,
      warning_fr: 'Notez ces codes de secours maintenant : ils ne seront plus jamais affichés.',
    });
  } catch (err: any) {
    res.status(500).json({ error_fr: "Erreur lors de l'enrôlement MFA.", details: err.message });
  }
}

export async function confirmMfa(req: Request, res: Response): Promise<void> {
  if (!req.user?.id) {
    res.status(401).json({ error_fr: 'Non authentifié.' });
    return;
  }
  const ip = req.ip || req.socket.remoteAddress || 'unknown-ip';
  const { token } = req.body;
  if (!token) {
    res.status(400).json({ error_fr: 'Code TOTP requis.' });
    return;
  }
  const ok = await confirmMfaEnrollment(req.user.id, token, ip);
  if (!ok) {
    res.status(401).json({ error_fr: 'Code invalide. Vérifiez votre application d\'authentification.' });
    return;
  }
  res.status(200).json({ message_fr: 'MFA activé avec succès.', success: true });
}

export async function verifyMfaLogin(req: Request, res: Response): Promise<void> {
  const ip = req.ip || req.socket.remoteAddress || 'unknown-ip';
  const { userId, code } = req.body;
  if (!userId || !code) {
    res.status(400).json({ error_fr: 'userId et code requis.' });
    return;
  }
  const ok = await verifyMfaCode(userId, code, ip);
  if (!ok) {
    res.status(401).json({ error_fr: 'Code MFA invalide ou expiré.' });
    return;
  }
  res.status(200).json({ success: true });
}
