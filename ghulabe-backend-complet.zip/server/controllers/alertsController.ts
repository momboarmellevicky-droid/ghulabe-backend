import { Request, Response } from 'express';
import { listAlertsForUser, markAlertAsRead } from '../services/alertsService';

export async function getMyAlerts(req: Request, res: Response): Promise<void> {
  if (!req.user?.id) {
    res.status(401).json({ error_fr: 'Non authentifié.' });
    return;
  }
  try {
    const alerts = await listAlertsForUser(req.user.id);
    res.status(200).json({ alerts });
  } catch (err: any) {
    res.status(500).json({ error_fr: 'Erreur lors de la récupération des alertes.', details: err.message });
  }
}

export async function markAlertRead(req: Request, res: Response): Promise<void> {
  if (!req.user?.id) {
    res.status(401).json({ error_fr: 'Non authentifié.' });
    return;
  }
  const { alertId } = req.params;
  const ok = await markAlertAsRead(alertId, req.user.id);
  if (!ok) {
    res.status(404).json({ error_fr: "Alerte introuvable ou non autorisée." });
    return;
  }
  res.status(200).json({ success: true });
}
