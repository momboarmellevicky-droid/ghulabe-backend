import { Router } from 'express';
import { enrollMfa, confirmMfa, verifyMfaLogin } from '../controllers/mfaController';
import { requireAuth } from '../middleware/authMiddleware';

const router = Router();

router.post('/enroll', requireAuth, enrollMfa);
router.post('/confirm', requireAuth, confirmMfa);
router.post('/verify-login', verifyMfaLogin); // pas de requireAuth : appelé avant l'émission du JWT final

export default router;
