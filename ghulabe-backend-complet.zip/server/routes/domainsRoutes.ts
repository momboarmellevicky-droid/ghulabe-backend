import { Router } from 'express';
import { getMyDomains } from '../controllers/domainsController';
import { requireAuth } from '../middleware/authMiddleware';

const router = Router();

router.get('/', requireAuth, getMyDomains);

export default router;
