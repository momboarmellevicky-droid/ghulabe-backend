import { Request, Response } from 'express';
import { initiateMobileMoneyPayment, checkPaymentStatus, MobileMoneyOperator } from '../services/paymentService';

// Clé partagée simple pour protéger cette route de diagnostic (pas de JWT
// nécessaire : conçue pour être ouverte depuis un navigateur mobile, sans
// app cliente ni terminal). Doit être définie dans .env : PAYMENT_TEST_KEY.
const TEST_KEY = process.env.PAYMENT_TEST_KEY;
const MAX_TEST_AMOUNT = 100; // FCFA — plafond de sécurité pour ces tests réels

function isAuthorized(req: Request): boolean {
  return Boolean(TEST_KEY) && req.query.key === TEST_KEY;
}

/**
 * GET /api/payments/test?amount=100&phone=074xxxxxx&operator=moov&key=...
 * Déclenche un VRAI paiement SingPay de faible montant et renvoie la
 * réponse brute intégrale (raw) pour identifier les vrais noms de champs
 * (transactionId, status) — actuellement non confirmés dans paymentService.ts.
 */
export async function testSingPayPayment(req: Request, res: Response): Promise<void> {
  if (!isAuthorized(req)) {
    res.status(404).json({ error_fr: 'Introuvable.' });
    return;
  }

  const amount = Number(req.query.amount);
  const phone = String(req.query.phone || '');
  const operator = String(req.query.operator || '') as MobileMoneyOperator;
  const ip = req.ip || req.socket.remoteAddress || 'unknown-ip';

  if (!amount || amount <= 0 || amount > MAX_TEST_AMOUNT) {
    res.status(400).json({ error_fr: `Montant invalide (max ${MAX_TEST_AMOUNT} FCFA pour un test).` });
    return;
  }
  if (!phone || !['airtel', 'moov'].includes(operator)) {
    res.status(400).json({ error_fr: 'Paramètres requis : phone, operator=airtel|moov.' });
    return;
  }

  const result = await initiateMobileMoneyPayment({
    amount,
    phoneNumber: phone,
    operator,
    reference: `TEST-${Date.now()}`,
    description: 'Test réel GHULABE — diagnostic intégration SingPay',
    userId: 'DIAGNOSTIC_TEST',
    ip,
  });

  // Renvoie tout, y compris raw : c'est précisément ce qu'on veut inspecter.
  res.status(200).json(result);
}

/**
 * GET /api/payments/test-status?transactionId=xxx&key=...
 */
export async function testSingPayStatus(req: Request, res: Response): Promise<void> {
  if (!isAuthorized(req)) {
    res.status(404).json({ error_fr: 'Introuvable.' });
    return;
  }

  const transactionId = String(req.query.transactionId || '');
  const ip = req.ip || req.socket.remoteAddress || 'unknown-ip';

  if (!transactionId) {
    res.status(400).json({ error_fr: 'Paramètre transactionId requis.' });
    return;
  }

  const result = await checkPaymentStatus(transactionId, 'DIAGNOSTIC_TEST', ip);
  res.status(200).json(result);
}
