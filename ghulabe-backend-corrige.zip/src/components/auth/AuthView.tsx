import React, { useState } from 'react';
import { supabase } from '../../lib/supabase';
import { Language } from '../../types';
import { Lock, Mail, User, Globe, ArrowRight, CheckCircle2, AlertOctagon } from 'lucide-react';

interface AuthViewProps {
  lang: Language;
  onSuccess?: () => void;
}

export const AuthView: React.FC<AuthViewProps> = ({ lang, onSuccess }) => {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [country, setCountry] = useState('Gabon');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setLoading(true);

    try {
      if (mode === 'register') {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: {
              name: fullName || email.split('@')[0],
              country
            }
          }
        });
        if (error) throw error;
        setSuccessMsg(lang === 'fr' 
          ? "✅ Inscription réussie ! Vous êtes connecté avec votre session JWT Supabase." 
          : "✅ Registration successful! Logged in with Supabase JWT session."
        );
        if (onSuccess) onSuccess();
      } else {
        const { error } = await supabase.auth.signInWithPassword({
          email,
          password
        });
        if (error) throw error;
        setSuccessMsg(lang === 'fr' 
          ? "✅ Connexion réussie ! Session JWT Supabase active." 
          : "✅ Login successful! Supabase JWT session active."
        );
        if (onSuccess) onSuccess();
      }
    } catch (err: any) {
      console.error('[Supabase Auth Error]', err);
      setErrorMsg(err.message || (lang === 'fr' ? "Erreur d'authentification." : "Authentication error."));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto my-6 p-6 sm:p-8 glass-card rounded-3xl border border-[#0066FF]/40 shadow-[0_0_40px_rgba(0,102,255,0.2)]">
      <div className="text-center mb-6">
        <span className="px-3 py-1 rounded-full bg-[#0066FF]/20 text-[#0066FF] font-mono text-xs font-bold uppercase tracking-wider">
          🔒 Supabase JWT Auth • AES-256
        </span>
        <h2 className="text-2xl font-display font-extrabold text-white mt-2">
          {mode === 'login' 
            ? (lang === 'fr' ? "Connexion GHULABE" : "GHULABE Login")
            : (lang === 'fr' ? "Créer un compte PME" : "Create SME Account")
          }
        </h2>
        <p className="text-xs text-gray-400 mt-1">
          {mode === 'login'
            ? (lang === 'fr' ? "Connectez-vous avec email et mot de passe" : "Login with email and password")
            : (lang === 'fr' ? "Inscrivez-vous avec email et mot de passe" : "Register with email and password")
          }
        </p>
      </div>

      {/* Tabs */}
      <div className="flex bg-[#0D1B2A] p-1 rounded-xl border border-white/10 font-display font-bold text-xs mb-6">
        <button
          type="button"
          onClick={() => { setMode('login'); setErrorMsg(''); setSuccessMsg(''); }}
          className={`flex-1 py-2.5 rounded-lg transition-all cursor-pointer ${
            mode === 'login' ? 'bg-[#0066FF] text-white shadow' : 'text-gray-400 hover:text-white'
          }`}
        >
          {lang === 'fr' ? "Connexion" : "Login"}
        </button>
        <button
          type="button"
          onClick={() => { setMode('register'); setErrorMsg(''); setSuccessMsg(''); }}
          className={`flex-1 py-2.5 rounded-lg transition-all cursor-pointer ${
            mode === 'register' ? 'bg-[#00FF88] text-[#0A0A0F] shadow font-extrabold' : 'text-gray-400 hover:text-white'
          }`}
        >
          {lang === 'fr' ? "Inscription" : "Register"}
        </button>
      </div>

      <form onSubmit={handleAuthSubmit} className="space-y-4 text-left text-xs sm:text-sm">
        {mode === 'register' && (
          <>
            <div className="space-y-1">
              <label className="font-mono text-gray-300 text-xs">
                {lang === 'fr' ? "Nom ou Raison Sociale" : "Full Name / Company"} *
              </label>
              <div className="relative">
                <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#0066FF]" />
                <input
                  type="text"
                  value={fullName}
                  onChange={e => setFullName(e.target.value)}
                  placeholder="ex: Mombo Armelle Vicky"
                  className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#0A0A0F] border border-[#0066FF]/50 text-white font-mono text-xs focus:border-[#00FF88] focus:outline-none"
                  required
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="font-mono text-gray-300 text-xs">
                {lang === 'fr' ? "Pays" : "Country"} *
              </label>
              <div className="relative">
                <Globe className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#0066FF]" />
                <select
                  value={country}
                  onChange={e => setCountry(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#0A0A0F] border border-[#0066FF]/50 text-white font-mono text-xs focus:border-[#00FF88] focus:outline-none"
                >
                  <option value="Gabon">Gabon</option>
                  <option value="Cameroun">Cameroun</option>
                  <option value="Sénégal">Sénégal</option>
                  <option value="Ghana">Ghana</option>
                  <option value="Nigeria">Nigeria</option>
                  <option value="Maroc">Maroc</option>
                  <option value="Kenya">Kenya</option>
                  <option value="Zimbabwe">Zimbabwe</option>
                </select>
              </div>
            </div>
          </>
        )}

        <div className="space-y-1">
          <label className="font-mono text-gray-300 text-xs">
            {lang === 'fr' ? "Email professionnel" : "Email address"} *
          </label>
          <div className="relative">
            <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#0066FF]" />
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="direction@entreprise.ga"
              className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#0A0A0F] border border-[#0066FF]/50 text-white font-mono text-xs focus:border-[#00FF88] focus:outline-none"
              required
            />
          </div>
        </div>

        <div className="space-y-1">
          <label className="font-mono text-gray-300 text-xs">
            {lang === 'fr' ? "Mot de passe" : "Password"} *
          </label>
          <div className="relative">
            <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#0066FF]" />
            <input
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="••••••••••••"
              className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#0A0A0F] border border-[#0066FF]/50 text-white font-mono text-xs focus:border-[#00FF88] focus:outline-none"
              required
              minLength={6}
            />
          </div>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-xl bg-[#FF2D2D]/15 border border-[#FF2D2D]/40 text-[#FF2D2D] text-xs font-bold flex items-center gap-2">
            <AlertOctagon className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="p-3 rounded-xl bg-[#00FF88]/15 border border-[#00FF88]/40 text-[#00FF88] text-xs font-bold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        <button
          type="submit"
          disabled={loading}
          className="w-full mt-2 py-3.5 rounded-xl bg-gradient-to-r from-[#0066FF] to-[#00FF88] hover:from-[#0052CC] hover:to-[#00CC6A] text-[#0A0A0F] font-display font-extrabold text-xs uppercase tracking-wider transition-all shadow-[0_0_20px_rgba(0,102,255,0.5)] cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
        >
          <span>
            {loading 
              ? (lang === 'fr' ? "Traitement..." : "Processing...")
              : (mode === 'login' ? (lang === 'fr' ? "Se connecter (Session JWT)" : "Sign In") : (lang === 'fr' ? "Créer compte & Se connecter" : "Register & Sign In"))
            }
          </span>
          {!loading && <ArrowRight className="w-4 h-4" />}
        </button>
      </form>
    </div>
  );
};
