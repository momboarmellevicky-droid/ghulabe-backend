import { Request, Response } from 'express';
import { supabaseAdmin } from '../config/supabase';
import { generateAuditLog } from '../utils/crypto';
import { runFullScan } from '../services/scanEngine';
import { generateFindingsFromScan, VulnerabilityFinding } from '../services/geminiAnalysis';
import { upsertDomainAfterScan } from '../services/domainsService';
import { createAlertsFromFindings } from '../services/alertsService';
import { checkAndConsumeCredit } from '../services/creditsService';

/**
 * Calcule un score de sécurité sur 10 à partir des faits réels du scan
 * (headers manquants, SSL invalide/expirant, fichiers exposés, gravité des
 * verdicts générés). Remplace le score fixe 3.2 précédemment codé en dur.
 */
function computeSecurityScore(
  headers: { hsts: boolean; csp: boolean; x_frame_options: boolean; x_content_type_options: boolean },
  ssl: { valid: boolean; expires_in_days: number },
  exposedFilesCount: number,
  findings: VulnerabilityFinding[]
): number {
  let score = 10;

  if (!headers.hsts) score -= 1.5;
  if (!headers.csp) score -= 1.5;
  if (!headers.x_frame_options) score -= 1;
  if (!headers.x_content_type_options) score -= 1;

  if (!ssl.valid) score -= 3;
  else if (ssl.expires_in_days < 14) score -= 1;

  score -= Math.min(exposedFilesCount, 3) * 1;

  for (const finding of findings) {
    if (finding.severity === 'critique') score -= 2;
    else if (finding.severity === 'eleve') score -= 1;
    else if (finding.severity === 'moyen') score -= 0.5;
    else score -= 0.2;
  }

  return Math.max(0, Math.round(score * 10) / 10);
}

export async function startScan(req: Request, res: Response): Promise<void> {
  const { url, legalCheckboxAccepted } = req.body;
  const ip = req.ip || req.socket.remoteAddress || 'unknown-ip';
  const userId = req.user?.id || 'ANONYMOUS';

  // MANDATORY CHECK : ACCORD OBLIGATOIRE CASE À COCHER
  if (!legalCheckboxAccepted) {
    generateAuditLog({
      action: 'SCAN_REJECTED_NO_LEGAL_CONSENT',
      userId,
      ipAddress: ip,
      targetUrl: url,
      status: 'BLOCKED',
      details: 'Tentative de scan sans avoir coché la case d\'autorisation externe obligatoire.',
    });

    res.status(403).json({
      error_fr: "⚠️ Accord obligatoire requis : Vous devez certifier être le propriétaire ou l'administrateur autorisé de ce domaine.",
      error_en: "⚠️ Mandatory agreement required: You must certify ownership of this domain before scanning.",
      code: 'MISSING_LEGAL_CONSENT',
    });
    return;
  }

  if (!url || typeof url !== 'string' || !url.includes('.')) {
    res.status(400).json({
      error_fr: "L'URL fournie est invalide. Veuillez renseigner un nom de domaine valide.",
      error_en: "Invalid URL provided.",
    });
    return;
  }

  // Quota par compte pour les utilisateurs connectés (le rate-limiter IP
  // ci-dessus reste le filet de sécurité pour les scans anonymes).
  if (userId !== 'ANONYMOUS') {
    const credit = await checkAndConsumeCredit(userId, req.user?.plan || 'gratuit', ip);
    if (!credit.allowed) {
      res.status(429).json({ error_fr: credit.error_fr, code: 'SCAN_CREDITS_EXHAUSTED' });
      return;
    }
  }

  const cleanUrl = url.replace(/^(https?:\/\/)?(www\.)?/, '').split('/')[0];
  const scanId = `scan-${Date.now()}`;

  generateAuditLog({
    action: 'SCAN_STARTED',
    userId,
    ipAddress: ip,
    targetUrl: cleanUrl,
    status: 'SUCCESS',
    details: 'Démarrage de l\'analyse externe asynchrone (Nuclei + Nmap + SSL Labs API) < 60s.',
  });

  try {
    // 1. Moteur de scan RÉEL : headers HTTP, certificat SSL/TLS, fichiers exposés
    const facts = await runFullScan(cleanUrl, userId, ip);

    // 2. Analyse IA Gemini à partir des faits réels (jamais de faille inventée hors faits constatés)
    const findings = await generateFindingsFromScan(facts, userId, ip);

    const score = computeSecurityScore(facts.headers_checked, facts.ssl_status, facts.exposed_files.length, findings);
    const durationSeconds = Math.round(facts.duration_ms / 1000);
    const reportPdfUrl = `https://ghulabe.com/reports/${scanId}.pdf`;

    // 3. Sauvegarde PostgreSQL sur Supabase EU
    const { error } = await supabaseAdmin.from('scans').insert({
      id: scanId,
      user_id: userId,
      url: cleanUrl,
      score,
      duration_seconds: durationSeconds,
      findings,
      report_pdf_url: reportPdfUrl,
      status: 'completed',
      created_at: new Date().toISOString(),
    });

    if (error && error.code !== '42P01') {
      console.warn('[GHULABE Scan] Sauvegarde DB simulée:', error.message);
    }

    // 4. Écriture réelle domains + alerts (no-op silencieux si scan anonyme)
    const domainId = await upsertDomainAfterScan(userId, cleanUrl, score, ip);
    if (domainId) {
      await createAlertsFromFindings(userId, domainId, cleanUrl, findings, ip);
    }

    generateAuditLog({
      action: 'SCAN_COMPLETED',
      userId,
      ipAddress: ip,
      targetUrl: cleanUrl,
      status: 'SUCCESS',
      details: `Scan terminé en ${durationSeconds}s. Score: ${score}/10. ${findings.length} faille(s) détectée(s).`,
    });

    res.status(200).json({
      message_fr: "Scan externe terminé.",
      message_en: "External scan completed.",
      scanId,
      url: cleanUrl,
      score,
      duration_seconds: durationSeconds,
      report_pdf_url: reportPdfUrl,
      findings,
      headers_checked: {
        hsts: facts.headers_checked.hsts,
        csp: facts.headers_checked.csp,
        x_frame_options: facts.headers_checked.x_frame_options,
        x_content_type_options: facts.headers_checked.x_content_type_options,
      },
      ssl_status: {
        valid: facts.ssl_status.valid,
        expires_in_days: facts.ssl_status.expires_in_days,
        issuer: facts.ssl_status.issuer,
      },
      exposed_files: facts.exposed_files,
    });
  } catch (err: any) {
    generateAuditLog({
      action: 'SCAN_FAILED',
      userId,
      ipAddress: ip,
      targetUrl: cleanUrl,
      status: 'FAILED',
      details: `Erreur critique lors du scan : ${err.message}`,
    });
    res.status(500).json({ error_fr: "Erreur critique lors du scan.", details: err.message });
  }
}

export async function getScanReport(req: Request, res: Response): Promise<void> {
  const { scanId } = req.params;
  if (!scanId) {
    res.status(400).json({ error_fr: "ID de scan manquant." });
    return;
  }

  // Simulation de récupération du rapport complet
  res.status(200).json({
    id: scanId,
    status: 'completed',
    score: 3.2,
    scan_duration_seconds: 48,
    created_at: new Date().toISOString(),
    ceoSection: {
      scoreLabel: "Score Global de Sécurité : 3.2 / 10",
      executiveSummary: "Niveau de danger CRITIQUE. 2 failles actives nécessitant une intervention sous 24 heures.",
    },
    devSection: {
      instructions: "Copiez-collez les blocs de code sécurisés fournis pour corriger les failles.",
    },
  });
}

export async function getScanHistory(req: Request, res: Response): Promise<void> {
  const { domainId } = req.params;
  res.status(200).json({
    domainId,
    totalScans: 4,
    latestScore: 3.2,
    history: [
      { id: 'scan-1', score: 3.2, date: new Date().toISOString() },
      { id: 'scan-2', score: 4.5, date: new Date(Date.now() - 86400000).toISOString() },
    ],
  });
}
