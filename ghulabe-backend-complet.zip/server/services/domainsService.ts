import { supabaseAdmin } from '../config/supabase';
import { generateAuditLog } from '../utils/crypto';

export type DomainStatus = 'safe' | 'warning' | 'critical' | 'unscanned';

export function statusFromScore(score: number): DomainStatus {
  if (score >= 8) return 'safe';
  if (score >= 5) return 'warning';
  return 'critical';
}

/**
 * Crée ou met à jour le domaine surveillé après un scan.
 * Upsert sur la contrainte UNIQUE(user_id, url) déjà en place en base.
 * Ne persiste rien pour les scans anonymes : sans user_id UUID valide,
 * il n'y a pas de propriétaire à qui rattacher le domaine (et l'insert
 * échouerait de toute façon sur la colonne user_id UUID NOT NULL).
 * Retourne l'id UUID du domaine (nécessaire pour lier les alertes), ou null.
 */
export async function upsertDomainAfterScan(
  userId: string,
  url: string,
  score: number,
  ip: string
): Promise<string | null> {
  if (!userId || userId === 'ANONYMOUS') return null;

  const status = statusFromScore(score);

  const { data, error } = await supabaseAdmin
    .from('domains')
    .upsert(
      {
        user_id: userId,
        url,
        status,
        score,
        last_scan: new Date().toISOString(),
      },
      { onConflict: 'user_id,url' }
    )
    .select('id')
    .single();

  if (error) {
    generateAuditLog({
      action: 'DOMAIN_UPSERT_FAILED',
      userId,
      ipAddress: ip,
      targetUrl: url,
      status: 'FAILED',
      details: `Échec de l'écriture du domaine après scan : ${error.message}`,
    });
    return null;
  }

  generateAuditLog({
    action: 'DOMAIN_UPSERTED',
    userId,
    ipAddress: ip,
    targetUrl: url,
    status: 'SUCCESS',
    details: `Domaine enregistré/mis à jour (status=${status}, score=${score}).`,
  });

  return data?.id ?? null;
}

/**
 * Liste les domaines d'un utilisateur (utilisé par GET /api/domains,
 * appelé par le front à la place de supabase.from('domains') direct).
 */
export async function listDomainsForUser(userId: string) {
  const { data, error } = await supabaseAdmin
    .from('domains')
    .select('*')
    .eq('user_id', userId)
    .order('last_scan', { ascending: false, nullsFirst: false });

  if (error) throw new Error(error.message);
  return data ?? [];
}
