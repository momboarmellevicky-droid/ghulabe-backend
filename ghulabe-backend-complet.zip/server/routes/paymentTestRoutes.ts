import { Router } from 'express';
import { testSingPayPayment, testSingPayStatus } from '../controllers/paymentTestController';

const router = Router();

router.get('/test', testSingPayPayment);
router.get('/test-status', testSingPayStatus);

export default router;
