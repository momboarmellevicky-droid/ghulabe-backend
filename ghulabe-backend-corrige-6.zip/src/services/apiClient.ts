import { ScanResult, Mission } from '../types';
import { MOCK_MISSIONS } from '../data/mockData';

// @ts-ignore
const API_BASE_URL = (import.meta && import.meta.env && import.meta.env.VITE_API_URL) || '/api';

/**
 * Interface frontend pour communiquer avec le Backend GHULABE (LWS Paris / Supabase EU)
 */
export const GhulabeBackend = {
  /**
   * 1. Connexion Étape 1 : Valide le mot de passe et déclenche l'envoi du challenge 2FA
   */
  async loginStep1(email: string, passwordHash: string): Promise<{ challengeId: string; devNote?: string }> {
    try {
      const res = await fetch(`${API_BASE_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password: passwordHash }),
      });
      if (!res.ok) throw new Error(await res.text());
      return await res.json();
    } catch (err: any) {
      console.warn('[GHULABE Backend Wrapper] Erreur loginStep1 (simulation locale):', err.message);
      // Fallback démo fluide si le serveur Express n'est pas lancé séparément
      return { challengeId: `2fa-demo-${Date.now()}`, devNote: 'Code 2FA: "2026"' };
    }
  },

  /**
   * 2. Connexion Étape 2 : Vérifie le code OTP 2FA et récupère le JWT (valable 24h)
   */
  async verify2FA(challengeId: string, otp: string): Promise<{ accessToken: string; user: any }> {
    try {
      const res = await fetch(`${API_BASE_URL}/auth/verify-2fa`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ challengeId, otp }),
      });
      if (!res.ok) throw new Error(await res.text());
      return await res.json();
    } catch (err: any) {
      console.warn('[GHULABE Backend Wrapper] Erreur verify2FA (simulation locale):', err.message);
      if (otp === '2026' || otp.length >= 4) {
        return {
          accessToken: 'jwt_mock_token_24h_expiry_verified_2fa',
          user: { id: 'usr-pme-master', email: 'direction@africacyber-pme.ga', role: 'admin', plan: 'gardien', is2faVerified: true },
        };
      }
      throw new Error('Code 2FA invalide.');
    }
  },

  /**
   * 3. Lance un scan externe asynchrone (moteur Nuclei + Nmap + SSL Labs API) < 60s
   */
  async startScan(url: string, legalCheckboxAccepted: boolean, token?: string): Promise<ScanResult> {
    try {
      const res = await fetch(`${API_BASE_URL}/scan/start`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ url, legalCheckboxAccepted }),
      });
      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error_fr || errData.error || 'Erreur lors du scan.');
      }
      return await res.json();
    } catch (err: any) {
      console.warn('[GHULABE Backend Wrapper] startScan fallback local:', err.message);
      // Transform error to be displayed in UI if needed
      throw err;
    }
  },

  /**
   * 4. Récupère les missions visibles par l'utilisateur (filtrage par rôle géré côté backend).
   * Sans token (session non encore branchée côté front), on retombe sur les données de
   * démonstration MOCK_MISSIONS plutôt que de casser l'affichage — même logique défensive
   * que loginStep1/verify2FA ci-dessus.
   */
  async getMissions(token?: string): Promise<Mission[]> {
    if (!token) {
      console.warn('[GHULABE Backend Wrapper] getMissions: aucun token de session disponible, utilisation des données de démonstration.');
      return MOCK_MISSIONS;
    }
    try {
      const res = await fetch(`${API_BASE_URL}/missions`, {
        method: 'GET',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json();
      return data.missions as Mission[];
    } catch (err: any) {
      console.warn('[GHULABE Backend Wrapper] Erreur getMissions (repli sur données de démonstration):', err.message);
      return MOCK_MISSIONS;
    }
  },

  /**
   * 0. Inscription : crée le compte côté backend (table users, mot de passe chiffré AES-256).
   * Ne renvoie pas de session : le backend impose la connexion via loginStep1 + verify2FA
   * juste après (2FA obligatoire), conformément à authController.ts.
   */
  async register(email: string, password: string, name: string, country: string): Promise<{ userId: string }> {
    const res = await fetch(`${API_BASE_URL}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, name, country }),
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error_fr || errData.error || 'Erreur lors de la création du compte.');
    }
    return await res.json();
  },

  /**
   * 5. Déconnexion côté backend (best-effort, pour la trace d'audit) : la déconnexion réelle
   * côté client se fait toujours en supprimant le token local, même si cet appel échoue.
   */
  async logout(token: string): Promise<void> {
    try {
      await fetch(`${API_BASE_URL}/auth/logout`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
    } catch (err: any) {
      console.warn('[GHULABE Backend Wrapper] logout best-effort échoué (sans impact) :', err.message);
    }
  },

  /**
   * 6. Récupère domaines + alertes + nombre de scans en un seul appel (remplace les 3 appels
   * Supabase directs auparavant faits depuis DashboardView.tsx, cassés — voir dashboardController.ts).
   * Sans token, on renvoie null : DashboardView garde alors ses valeurs mock/props existantes
   * plutôt que d'afficher un tableau vide.
   */
  async getDashboardData(token?: string): Promise<{ domains: any[]; alerts: any[]; scansCount: number } | null> {
    if (!token) {
      console.warn('[GHULABE Backend Wrapper] getDashboardData: aucun token de session disponible.');
      return null;
    }
    try {
      const res = await fetch(`${API_BASE_URL}/dashboard`, {
        method: 'GET',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error(await res.text());
      return await res.json();
    } catch (err: any) {
      console.warn('[GHULABE Backend Wrapper] Erreur getDashboardData:', err.message);
      return null;
    }
  },
};
