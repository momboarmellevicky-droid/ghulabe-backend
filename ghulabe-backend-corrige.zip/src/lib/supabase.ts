import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://ycnugbfkfytrasvimgxg.supabase.co'
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'ta_clé_publiable_ici'

export const supabase = createClient(supabaseUrl, supabaseKey)
