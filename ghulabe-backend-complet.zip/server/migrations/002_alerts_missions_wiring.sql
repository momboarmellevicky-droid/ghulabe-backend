-- ============================================================
-- PATCH 002 — additif uniquement, sans risque sur données existantes
-- ============================================================

-- ALERTS : ajout de user_id dénormalisé (le service backend le remplit à
-- l'insert via une jointure sur domains.user_id) + message_fr/message_en
-- bilingues, alignés sur le type Alert du front (message générique conservé).
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS user_id UUID REFERENCES users(id) ON DELETE CASCADE;
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS message_fr TEXT;
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS message_en TEXT;
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS is_read BOOLEAN NOT NULL DEFAULT false;

CREATE INDEX IF NOT EXISTS idx_alerts_user_id ON alerts(user_id);

-- MISSIONS : colonnes attendues par src/types.ts (Mission) absentes du script
-- initial. developer_id ajouté en plus d'assigned_dev_id (compat front).
ALTER TABLE missions ADD COLUMN IF NOT EXISTS developer_id UUID REFERENCES users(id) ON DELETE SET NULL;
ALTER TABLE missions ADD COLUMN IF NOT EXISTS description TEXT;
ALTER TABLE missions ADD COLUMN IF NOT EXISTS url TEXT;
ALTER TABLE missions ADD COLUMN IF NOT EXISTS legal_checkbox_accepted BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE missions ADD COLUMN IF NOT EXISTS rating_stars INT;
ALTER TABLE missions ADD COLUMN IF NOT EXISTS rating_review TEXT;

DO $$ BEGIN
  ALTER TABLE missions ADD CONSTRAINT missions_rating_stars_check CHECK (rating_stars IS NULL OR rating_stars BETWEEN 1 AND 5);
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- Policy INSERT manquante pour missions (le client crée sa propre mission)
DROP POLICY IF EXISTS "missions_insert_own" ON missions;
CREATE POLICY "missions_insert_own" ON missions
  FOR INSERT WITH CHECK (client_id = auth.uid());

-- Policy UPDATE pour qu'un dev assigné puisse mettre à jour le statut
DROP POLICY IF EXISTS "missions_update_involved" ON missions;
CREATE POLICY "missions_update_involved" ON missions
  FOR UPDATE USING (client_id = auth.uid() OR developer_id = auth.uid() OR assigned_dev_id = auth.uid());
