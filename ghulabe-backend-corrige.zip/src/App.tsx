import React, { useState, useEffect } from 'react';
import { Language, TabType, User, Domain } from './types';
import { Header } from './components/common/Header';
import { Footer } from './components/common/Footer';
import { BottomNav } from './components/common/BottomNav';
import { SecurityHeadersBanner } from './components/common/SecurityHeadersBanner';
import { HomeView } from './components/home/HomeView';
import { ScanView } from './components/scan/ScanView';
import { DashboardView } from './components/dash/DashboardView';
import { DevsPortalView } from './components/devs/DevsPortalView';
import { MeView } from './components/me/MeView';
import { LegalModal } from './components/legal/LegalModal';
import { supabase } from './lib/supabase';
import { AuthView } from './components/auth/AuthView';

export const App: React.FC = () => {
  const [lang, setLang] = useState<Language>('fr');
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [sessionUser, setSessionUser] = useState<User | null>(null);

  // Active user mock state (Mombo Armelle Vicky / SME Client)
  const [currentUser, setCurrentUser] = useState<User>({
    id: 'usr-pme-master',
    email: 'direction@africacyber-pme.ga',
    name: 'Mombo Armelle Vicky',
    country: 'Gabon',
    role: 'admin',
    plan: 'gardien',
    created_at: '2026-01-01T00:00:00.000Z',
    is2FAEnabled: true
  });

  // Monitored domains state
  const [domains, setDomains] = useState<Domain[]>([
    {
      id: 'dom-1',
      user_id: 'usr-pme-master',
      url: 'ebanking-pme-africa.sn',
      last_scan: 'Il y a 2 heures',
      score: 3.2,
      status: 'critical'
    },
    {
      id: 'dom-2',
      user_id: 'usr-pme-master',
      url: 'store-dakar-express.com',
      last_scan: 'Hier à 14:20',
      score: 8.5,
      status: 'safe'
    },
    {
      id: 'dom-3',
      user_id: 'usr-pme-master',
      url: 'assurances-libreville.ga',
      last_scan: '12 Janvier 2026',
      score: 6.4,
      status: 'warning'
    }
  ]);

  // Scanner direct launch state
  const [scanTargetUrl, setScanTargetUrl] = useState('ebanking-pme-africa.sn');
  const [isScanAutoStarted, setIsScanAutoStarted] = useState(false);
  const [devPortalMode, setDevPortalMode] = useState<'find' | 'become'>('find');
  const [legalPage, setLegalPage] = useState<'mentions' | 'privacy' | 'cgu' | 'disclaimer' | 'cookies' | null>(null);

  // Set document title dynamically
  useEffect(() => {
    document.title = lang === 'fr' 
      ? "GHULABE — 1ère plateforme de cybersécurité bilingue pour PME africaines"
      : "GHULABE — 1st bilingual cybersecurity platform for African SMEs";
  }, [lang]);

  // Connect authentication & stay logged in with JWT session
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        setSessionUser({
          id: session.user.id,
          email: session.user.email || '',
          name: session.user.user_metadata?.name || session.user.email?.split('@')[0] || 'Mombo Armelle Vicky',
          country: session.user.user_metadata?.country || 'Gabon',
          role: session.user.email?.includes('master') || session.user.email?.includes('mombo') || session.user.email?.includes('direction') ? 'admin' : 'user',
          plan: 'gardien',
          created_at: session.user.created_at || '2026-01-01T00:00:00.000Z',
          is2FAEnabled: true
        });
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        setSessionUser({
          id: session.user.id,
          email: session.user.email || '',
          name: session.user.user_metadata?.name || session.user.email?.split('@')[0] || 'Mombo Armelle Vicky',
          country: session.user.user_metadata?.country || 'Gabon',
          role: session.user.email?.includes('master') || session.user.email?.includes('mombo') || session.user.email?.includes('direction') ? 'admin' : 'user',
          plan: 'gardien',
          created_at: session.user.created_at || '2026-01-01T00:00:00.000Z',
          is2FAEnabled: true
        });
      } else {
        setSessionUser(null);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleStartQuickScan = (url: string, _consentAccepted: boolean) => {
    setScanTargetUrl(url);
    setIsScanAutoStarted(true);
    setActiveTab('scan');
  };

  const handleAddMonitoredDomain = (url: string) => {
    const newDom: Domain = {
      id: `dom-${Date.now()}`,
      user_id: currentUser.id,
      url,
      last_scan: 'En attente scan externe',
      score: 7.0,
      status: 'warning'
    };
    setDomains([newDom, ...domains]);
    alert(lang === 'fr' ? `Domaine "${url}" ajouté à la surveillance Gardien 24/7 !` : `Domain "${url}" added to continuous surveillance!`);
  };

  const handleUpgradePlan = (newPlan: 'gratuit' | 'gardien' | 'pentest_premium') => {
    setCurrentUser({
      ...currentUser,
      plan: newPlan
    });
    alert(lang === 'fr' 
      ? `🎉 Félicitations ! Offre ${newPlan.toUpperCase()} activée sur LWS Paris.\n\nPaiement FCFA confirmé et chiffrement AES-256 en place.`
      : `🎉 Plan upgraded to ${newPlan.toUpperCase()}!`
    );
  };

  return (
    <div className="min-h-screen flex flex-col justify-between bg-[#0A0A0F] text-gray-100 selection:bg-[#0066FF] selection:text-white">
      
      {/* Security Headers Production Telemetry Banner */}
      <SecurityHeadersBanner />

      {/* Main Header (Bilingual toggle, Navigation, CTA) */}
      <Header
        lang={lang}
        setLang={setLang}
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setIsScanAutoStarted(false);
          setActiveTab(tab);
        }}
        currentUser={sessionUser || currentUser}
      />

      {/* Main Content Body */}
      <main className="flex-1 w-full transition-all duration-300">
        {activeTab === 'home' && (
          <HomeView
            lang={lang}
            onStartScan={handleStartQuickScan}
            setActiveTab={(tab) => {
              if (tab === 'devs') setDevPortalMode('become');
              setActiveTab(tab);
            }}
            onSelectPlan={handleUpgradePlan}
          />
        )}

        {activeTab === 'scan' && (
          <ScanView
            lang={lang}
            initialUrl={scanTargetUrl}
            initialScanActive={isScanAutoStarted}
            setActiveTab={setActiveTab}
            onScanComplete={() => {
              setIsScanAutoStarted(false);
            }}
          />
        )}

        {activeTab === 'dash' && (
          <DashboardView
            lang={lang}
            currentUser={sessionUser || currentUser}
            domains={domains}
            onAddDomain={handleAddMonitoredDomain}
            setActiveTab={setActiveTab}
            onSelectPlan={handleUpgradePlan}
          />
        )}

        {activeTab === 'devs' && (
          <DevsPortalView
            lang={lang}
            initialMode={devPortalMode}
          />
        )}

        {activeTab === 'me' && (
          sessionUser ? (
            <MeView
              lang={lang}
              currentUser={sessionUser}
              onLogout={async () => {
                await supabase.auth.signOut();
                alert(lang === 'fr' ? "Déconnexion réussie de votre session Supabase JWT." : "Successfully logged out.");
              }}
              onOpenLegal={(page) => setLegalPage(page)}
            />
          ) : (
            <div className="space-y-6">
              <AuthView
                lang={lang}
                onSuccess={() => {}}
              />
              <div className="text-center">
                <button
                  type="button"
                  onClick={() => setSessionUser(currentUser)}
                  className="text-xs text-gray-500 hover:text-[#00FF88] underline font-mono cursor-pointer"
                >
                  {lang === 'fr' ? "⚡ Mode démo : Se connecter en tant qu'admin Mombo Armelle Vicky" : "⚡ Demo mode: Login as admin Mombo Armelle Vicky"}
                </button>
              </div>
            </div>
          )
        )}
      </main>

      {/* Legal Modal Component */}
      <LegalModal
        lang={lang}
        page={legalPage}
        onClose={() => setLegalPage(null)}
      />

      {/* Footer on all pages (Exclusif) */}
      <Footer
        lang={lang}
        onOpenLegal={(page) => setLegalPage(page)}
      />

      {/* Bottom Navigation on mobile devices */}
      <BottomNav
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setIsScanAutoStarted(false);
          setActiveTab(tab);
        }}
        lang={lang}
      />

    </div>
  );
};

export default App;
