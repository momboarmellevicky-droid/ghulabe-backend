import { Router } from 'express';
import { startScan, getScanReport, getScanHistory } from '../controllers/scanController';
import { scanRateLimiter, apiRateLimiter } from '../middleware/rateLimiter';
import { optionalAuth } from '../middleware/authMiddleware';

const router = Router();

// Route principale de démarrage de scan (scan anonyme autorisé, mais optionalAuth
// remplit req.user si l'appelant est connecté, pour que le scan/domaine/alerte
// soient bien rattachés à son compte au lieu de retomber sur 'ANONYMOUS')
router.post('/start', optionalAuth, scanRateLimiter, startScan);

// Routes de rapports et d'historique
router.get('/report/:scanId', apiRateLimiter, getScanReport);
router.get('/history/:domainId', apiRateLimiter, getScanHistory);

export default router;
