import { supabaseAdmin } from '../config/supabase';
import { generateAuditLog } from '../utils/crypto';

export interface CreateMissionInput {
  clientId: string;
  alertId?: string;
  url: string;
  description: string;
  urgency: 'Faible' | 'Moyen' | 'Élevé' | 'Critique';
  budgetFcfa: number;
  legalCheckboxAccepted: boolean;
}

/**
 * Publie une mission freelance payante liée (optionnellement) à une alerte
 * détectée par un scan. C'est le maillon "monétisation" du cycle
 * détection → correction du modèle marketplace GHULABE.
 */
export async function createMission(input: CreateMissionInput, ip: string) {
  if (!input.legalCheckboxAccepted) {
    throw new Error('LEGAL_CONSENT_REQUIRED');
  }
  if (!input.budgetFcfa || input.budgetFcfa <= 0) {
    throw new Error('INVALID_BUDGET');
  }

  const { data, error } = await supabaseAdmin
    .from('missions')
    .insert({
      client_id: input.clientId,
      alert_id: input.alertId ?? null,
      url: input.url,
      description: input.description,
      urgency: input.urgency,
      budget_fcfa: input.budgetFcfa,
      legal_checkbox_accepted: true,
      status: 'requested',
      created_at: new Date().toISOString(),
    })
    .select('*')
    .single();

  if (error) {
    generateAuditLog({
      action: 'MISSION_CREATE_FAILED',
      userId: input.clientId,
      ipAddress: ip,
      targetUrl: input.url,
      status: 'FAILED',
      details: `Échec de la création de mission : ${error.message}`,
    });
    throw new Error(error.message);
  }

  generateAuditLog({
    action: 'MISSION_CREATED',
    userId: input.clientId,
    ipAddress: ip,
    targetUrl: input.url,
    status: 'SUCCESS',
    details: `Mission publiée : ${input.budgetFcfa} FCFA, urgence ${input.urgency}.`,
  });

  return data;
}

/** Missions ouvertes (marketplace, visibles par tous les devs certifiés) */
export async function listOpenMissions() {
  const { data, error } = await supabaseAdmin
    .from('missions')
    .select('*')
    .eq('status', 'requested')
    .order('created_at', { ascending: false });

  if (error) throw new Error(error.message);
  return data ?? [];
}

/** Missions liées à un utilisateur (côté client OU côté développeur assigné) */
export async function listMyMissions(userId: string) {
  const { data, error } = await supabaseAdmin
    .from('missions')
    .select('*')
    .or(`client_id.eq.${userId},developer_id.eq.${userId}`)
    .order('created_at', { ascending: false });

  if (error) throw new Error(error.message);
  return data ?? [];
}

export async function assignMission(missionId: string, developerId: string) {
  const { data, error } = await supabaseAdmin
    .from('missions')
    .update({ developer_id: developerId, status: 'accepted' })
    .eq('id', missionId)
    .eq('status', 'requested')
    .select('*')
    .single();

  if (error) throw new Error(error.message);
  return data;
}
