import { Router } from 'express';
import {
  postMission,
  getOpenMissions,
  getMyMissions,
  acceptMission,
} from '../controllers/missionsController';
import { requireAuth } from '../middleware/authMiddleware';

const router = Router();

router.post('/', requireAuth, postMission);
router.get('/open', getOpenMissions); // marketplace public, pas d'auth requise pour parcourir
router.get('/mine', requireAuth, getMyMissions);
router.patch('/:missionId/accept', requireAuth, acceptMission);

export default router;
