import { supabaseAdmin } from '../config/supabase';
import { generateAuditLog } from '../utils/crypto';

const PLAN_HOURLY_CREDITS: Record<string, number> = {
  gratuit: 10,
  gardien: 60,
  pentest_premium: 999999, // illimité en pratique
};

/**
 * Vérifie et consomme un crédit de scan pour un utilisateur authentifié.
 * Remplace le rate-limiter par IP (toujours actif en filet de sécurité
 * anti-abus pour les scans anonymes) par un vrai quota par compte, aligné
 * sur le plan (gratuit/gardien/pentest_premium), persistant en base.
 * Réinitialise automatiquement la fenêtre toutes les heures.
 */
export async function checkAndConsumeCredit(
  userId: string,
  plan: string,
  ip: string
): Promise<{ allowed: boolean; remaining: number; error_fr?: string }> {
  const now = new Date();

  let { data: row, error } = await supabaseAdmin
    .from('scan_credits')
    .select('*')
    .eq('user_id', userId)
    .single();

  if (error || !row) {
    // Première utilisation : création de la ligne de crédits pour ce user
    const { data: created, error: createErr } = await supabaseAdmin
      .from('scan_credits')
      .insert({
        user_id: userId,
        plan,
        credits_remaining: PLAN_HOURLY_CREDITS[plan] ?? 10,
        credits_reset_at: new Date(now.getTime() + 3600_000).toISOString(),
      })
      .select('*')
      .single();

    if (createErr || !created) {
      return { allowed: true, remaining: -1 }; // fail-open : ne bloque pas un scan pour un souci d'infra
    }
    row = created;
  }

  // Reset de fenêtre horaire si échue
  if (new Date(row.credits_reset_at) <= now) {
    const resetCredits = PLAN_HOURLY_CREDITS[plan] ?? 10;
    const { data: reset } = await supabaseAdmin
      .from('scan_credits')
      .update({
        plan,
        credits_remaining: resetCredits,
        credits_reset_at: new Date(now.getTime() + 3600_000).toISOString(),
      })
      .eq('user_id', userId)
      .select('*')
      .single();
    row = reset ?? row;
  }

  if (row.credits_remaining <= 0) {
    generateAuditLog({
      action: 'SCAN_CREDIT_EXHAUSTED',
      userId, ipAddress: ip, status: 'BLOCKED',
      details: `Quota de scans épuisé pour le plan ${plan}. Reset à ${row.credits_reset_at}.`,
    });
    return {
      allowed: false,
      remaining: 0,
      error_fr: `Quota de scans atteint pour votre plan (${plan}). Réinitialisation à ${new Date(row.credits_reset_at).toLocaleTimeString('fr-FR')}.`,
    };
  }

  await supabaseAdmin
    .from('scan_credits')
    .update({
      credits_remaining: row.credits_remaining - 1,
      total_scans_used: (row.total_scans_used ?? 0) + 1,
    })
    .eq('user_id', userId);

  return { allowed: true, remaining: row.credits_remaining - 1 };
}
