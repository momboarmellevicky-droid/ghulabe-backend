import { supabaseAdmin } from '../config/supabase';
import { generateAuditLog } from '../utils/crypto';
import type { VulnerabilityFinding } from './geminiAnalysis';

/**
 * Crée une alerte par faille de sévérité critique ou élevée détectée lors
 * d'un scan. Les failles "moyen"/"faible" restent visibles dans le rapport
 * PDF mais ne déclenchent pas d'alerte SMS/Email (évite le bruit).
 * Utilise ceo_impact_fr/en (déjà rédigé pour un public non-technique par
 * Gemini) comme corps du message, plus lisible qu'un détail technique brut.
 */
export async function createAlertsFromFindings(
  userId: string,
  domainId: string | null,
  domainUrl: string,
  findings: VulnerabilityFinding[],
  ip: string
): Promise<number> {
  if (!userId || userId === 'ANONYMOUS' || !domainId) return 0;

  const alertable = findings.filter(f => f.severity === 'critique' || f.severity === 'eleve');
  if (alertable.length === 0) return 0;

  const rows = alertable.map(f => ({
    domain_id: domainId,
    user_id: userId,
    severity: f.severity,
    message: f.ceo_impact_fr, // colonne historique conservée pour compatibilité
    message_fr: `${f.title_fr} — ${f.ceo_impact_fr}`,
    message_en: `${f.title_en} — ${f.ceo_impact_en}`,
    is_read: false,
    created_at: new Date().toISOString(),
  }));

  const { data, error } = await supabaseAdmin.from('alerts').insert(rows).select('id');

  if (error) {
    generateAuditLog({
      action: 'ALERTS_INSERT_FAILED',
      userId,
      ipAddress: ip,
      targetUrl: domainUrl,
      status: 'FAILED',
      details: `Échec de la création des alertes : ${error.message}`,
    });
    return 0;
  }

  generateAuditLog({
    action: 'ALERTS_CREATED',
    userId,
    ipAddress: ip,
    targetUrl: domainUrl,
    status: 'SUCCESS',
    details: `${data?.length ?? 0} alerte(s) créée(s) (critique/élevé) sur ${domainUrl}.`,
  });

  return data?.length ?? 0;
}

/**
 * Liste les alertes d'un utilisateur, jointes au domaine pour fournir
 * domain_url directement (le type Alert front l'attend dénormalisé).
 */
export async function listAlertsForUser(userId: string) {
  const { data, error } = await supabaseAdmin
    .from('alerts')
    .select('id, domain_id, severity, message_fr, message_en, is_read, created_at, domains(url)')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) throw new Error(error.message);

  return (data ?? []).map((row: any) => ({
    id: row.id,
    domain_id: row.domain_id,
    domain_url: row.domains?.url ?? '',
    severity: row.severity,
    message_fr: row.message_fr,
    message_en: row.message_en,
    is_read: row.is_read,
    created_at: row.created_at,
  }));
}

export async function markAlertAsRead(alertId: string, userId: string): Promise<boolean> {
  const { error } = await supabaseAdmin
    .from('alerts')
    .update({ is_read: true })
    .eq('id', alertId)
    .eq('user_id', userId);

  return !error;
}
