import { Request, Response } from 'express';
import {
  createMission,
  listOpenMissions,
  listMyMissions,
  assignMission,
} from '../services/missionsService';
import { generateAuditLog } from '../utils/crypto';

export async function postMission(req: Request, res: Response): Promise<void> {
  const ip = req.ip || req.socket.remoteAddress || 'unknown-ip';
  if (!req.user?.id) {
    res.status(401).json({ error_fr: 'Non authentifié.' });
    return;
  }

  const { url, description, urgency, budget_fcfa, alert_id, legalCheckboxAccepted } = req.body;

  if (!legalCheckboxAccepted) {
    generateAuditLog({
      action: 'MISSION_REJECTED_NO_LEGAL_CONSENT',
      userId: req.user.id,
      ipAddress: ip,
      status: 'BLOCKED',
      details: "Tentative de publication de mission sans case d'autorisation cochée.",
    });
    res.status(403).json({
      error_fr: "⚠️ Vous devez certifier être autorisé à commander cette correction.",
      code: 'MISSING_LEGAL_CONSENT',
    });
    return;
  }

  if (!url || !description || !urgency || !budget_fcfa) {
    res.status(400).json({ error_fr: 'Champs manquants : url, description, urgency, budget_fcfa requis.' });
    return;
  }

  try {
    const mission = await createMission(
      {
        clientId: req.user.id,
        alertId: alert_id,
        url,
        description,
        urgency,
        budgetFcfa: Number(budget_fcfa),
        legalCheckboxAccepted: true,
      },
      ip
    );
    res.status(201).json({ mission });
  } catch (err: any) {
    res.status(500).json({ error_fr: 'Erreur lors de la publication de la mission.', details: err.message });
  }
}

export async function getOpenMissions(_req: Request, res: Response): Promise<void> {
  try {
    const missions = await listOpenMissions();
    res.status(200).json({ missions });
  } catch (err: any) {
    res.status(500).json({ error_fr: 'Erreur lors de la récupération des missions.', details: err.message });
  }
}

export async function getMyMissions(req: Request, res: Response): Promise<void> {
  if (!req.user?.id) {
    res.status(401).json({ error_fr: 'Non authentifié.' });
    return;
  }
  try {
    const missions = await listMyMissions(req.user.id);
    res.status(200).json({ missions });
  } catch (err: any) {
    res.status(500).json({ error_fr: 'Erreur lors de la récupération de vos missions.', details: err.message });
  }
}

export async function acceptMission(req: Request, res: Response): Promise<void> {
  if (!req.user?.id) {
    res.status(401).json({ error_fr: 'Non authentifié.' });
    return;
  }
  const { missionId } = req.params;
  try {
    const mission = await assignMission(missionId, req.user.id);
    res.status(200).json({ mission });
  } catch (err: any) {
    res.status(409).json({ error_fr: 'Mission déjà assignée ou introuvable.', details: err.message });
  }
}
